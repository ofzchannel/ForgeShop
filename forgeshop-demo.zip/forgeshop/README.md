# ForgeShop – FiveM Marketplace Demo

Demo static responsive în română, pentru scripturi FiveM vRP / QBCore / Standalone. Deschide `index.html` în browser sau publică întreg folderul pe Cloudflare Pages / Netlify / GitHub Pages.

## Ce funcționează
- Căutare live, filtre pentru framework, preț și categorii
- 9 produse demonstrative, pagină modală pentru detalii
- Adăugare / ștergere în coș, total automat
- Responsive desktop/mobile

## Ce NU este funcțional încă
- Produsele sunt fictive, fără fișiere reale și fără drepturi de distribuție asociate
- Nu există autentificare, bază de date, comenzi sau livrare
- Checkout-ul Stripe este *intenționat dezactivat*, nu colectează date de card și nu încasează bani

## Activarea reală a Stripe (necesită backend)
1. Configurează Stripe în contul comerciantului și produsele/prețurile în baza de date.
2. Creează un endpoint server-side `/api/checkout` care verifică prețurile reale din baza de date, *nu* din browser, și creează un Stripe Checkout Session.
3. Redirecționează utilizatorul la URL-ul sesiunii returnate. Nu introduce niciodată cheia secretă în `app.js`.
4. Verifică semnătura webhookului `checkout.session.completed` și îndeplinește comanda doar după confirmarea plății.
5. Adaugă conturi, termeni, politică de confidențialitate, facturare, condiții de rambursare și mecanism sigur de livrare.

Pe hosting static gratuit, pentru Stripe ai nevoie de Functions / alt serviciu backend și de chei Stripe proprii. Demo-ul nu are nevoie de acestea.
